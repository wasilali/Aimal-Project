import {LOGIN_REQUEST,LOGIN_SUCCESS,LOGIN_FAIL,CLEAR_ERRORS,REGISTER_REQUEST,REGISTER_SUCCESS,REGISTER_FAIL,LOAD_USER_REQUEST,LOAD_USER_SUCCESS,LOAD_USER_FAIL
,LOGOUT_SUCCESS,
LOGOUT_FAIL,
UPDATE_PROFILE_REQUEST,
UPDATE_PROFILE_SUCCESS,
UPDATE_PROFILE_FAIL,
UPDATE_PASSWORD_REQUEST,
UPDATE_PASSWORD_SUCCESS,
UPDATE_PASSWORD_FAIL,
FORGOT_PASSWORD_REQUEST,
FORGOT_PASSWORD_SUCCESS,
FORGOT_PASSWORD_FAIL,
RESET_PASSWORD_REQUEST,
RESET_PASSWORD_SUCCESS,
RESET_PASSWORD_FAIL,
ALL_USERS_REQUEST,
ALL_USERS_SUCCESS,
ALL_USERS_FAIL,
DELETE_USER_REQUEST,
DELETE_USER_SUCCESS,
DELETE_USER_FAIL,
DELETE_USER_RESET,
UPDATE_USER_REQUEST,
UPDATE_USER_SUCCESS,
UPDATE_USER_FAIL,
UPDATE_USER_RESET,
USER_DETAILS_REQUEST,
USER_DETAILS_SUCCESS,
USER_DETAILS_FAIL,
} from "../constants/userConstants"

import axios from "axios";
//login
export const loginUser = (email)=>async(dispatch)=>{

    try {
        dispatch({ type:LOGIN_REQUEST });
            const config= { Headers:{"Content-type":"application/json"} };
        const { data }=await axios.post(`/api/v2/login`,email,config)
        dispatch({
            type:LOGIN_SUCCESS,
            payload:data.user
        })
        
    } catch (error) {
        dispatch({
            type:LOGIN_FAIL,
            payload:error.response.data.message
        });
    }
};
//register
export const signup = (userData)=>async(dispatch)=>{

    try {
        dispatch({ type:REGISTER_REQUEST });

        //kue ka img use honi ic leya multipart use hoa ha
            const config= { Headers:{"Content-type":"multipart/form-data"} };
        const { data }=await axios.post(`/api/v2/register`,userData,config)
        dispatch({
            type:REGISTER_SUCCESS,
            payload:data.user
        })
    } catch (error) {
        dispatch({
            type:REGISTER_FAIL,
            payload:error.response.data.message
        });
    }
};





//loard user,...
export const loardUser = ()=>async(dispatch)=>{

    try {
        dispatch({ type:LOAD_USER_REQUEST });
        const { data }=await axios.get(`/api/v2/me`)
        dispatch({
            type:LOAD_USER_SUCCESS,
            payload:data.user
        })
        
    } catch (error) {
        dispatch({
            type:LOAD_USER_FAIL,
            payload:error.response.data.message
        });
    }
};


//logout
export const logoutUser = ()=>async(dispatch)=>{

    try {
        dispatch({ type:LOAD_USER_REQUEST });
        await axios.get(`/api/v2/logout`)
        dispatch({ type:LOGOUT_SUCCESS })
        
    } catch (error) {
        dispatch({
            type:LOGOUT_FAIL,
            payload:error.response.data.message
        });
    }
};

// Clearing errors
export const clearErrors=()=> async (dispatch)=>{
    dispatch({ type:CLEAR_ERRORS })
}



//update profile
export const updateProfile = (userData)=>async(dispatch)=>{

    try {
        dispatch({ type:UPDATE_PROFILE_REQUEST });
        const config= { Headers:{"Content-type":"multipart/form-data"} };
        const { data }=await axios.put(`/api/v2/me/update`,userData,config)
        dispatch({
            type:UPDATE_PROFILE_SUCCESS,
            payload:data.success,
        });
    } catch (error) {
        dispatch({
            type:UPDATE_PROFILE_FAIL,
            payload:error.response.data.message,
        });
    }
};

//Update Pass
export const updatePassword = (pass)=>async(dispatch)=>{

    try {
        dispatch({ type:UPDATE_PASSWORD_REQUEST });

        //kue ka img use honi ic leya multipart use hoa ha
            const config= { Headers:{"Content-type":"application/json"} };
        const { data }=await axios.put(`/api/v2/password/update`,pass,config)
        dispatch({
            type:UPDATE_PASSWORD_SUCCESS,
            payload:data.user
        })
    } catch (error) {
        dispatch({
            type:UPDATE_PASSWORD_FAIL,
            payload:error.response.data.message
        });
    }
}

