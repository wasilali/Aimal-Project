import React from 'react'
import { useAlert } from 'react-alert'
import { useDispatch, useSelector } from 'react-redux'
import { Link } from 'react-router-dom'
import { logoutUser } from '../../actions/userAction'
import "./Navbar.css"
const Navbar = () => {
  const dispatch=useDispatch();
  const alert=useAlert();
    const {loading,isAuthenticated,user}=useSelector(state=>state.user);
function logout() {
  dispatch(logoutUser())
  alert.success("logout Successfully")
  
}
  return <>
  <nav className="navbar bg-dark">
  <h1>
    <Link to="/">
      <i className="fas fa-code"/> DevConnector
    </Link>
  </h1>
  <ul>
  <li> <Link to="/profiles">Developers</Link>
    </li>
    <li>
     {isAuthenticated&& <Link to="/dashboard">Dashboard</Link>}
    </li>
    <li>
    {!isAuthenticated&&<Link to="/register">Register</Link>}
    </li>
    <li>
    {!isAuthenticated&&<Link to="/login">Login</Link>}
    
    </li>
    <li>
    {isAuthenticated&& <button className='logoutButton' onClick={logout} >logout</button>}
    </li>
  </ul>
</nav>

  </>
}

export default Navbar